"""
Linear (sequential) Search - Python implementation with simple test.
Returns index or -1.
"""

def linear_search(arr, target):
    for i, v in enumerate(arr):
        if v == target:
            return i
    return -1

if __name__ == "__main__":
    a = [3,5,2,7,9,1,4]
    t = 7
    print("Array:", a)
    print("Target:", t)
    print("Index:", linear_search(a, t))
