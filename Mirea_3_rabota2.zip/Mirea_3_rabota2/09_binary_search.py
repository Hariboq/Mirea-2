"""
Binary Search (iterative) - works on sorted arrays. Returns index or -1.
"""

def binary_search(arr, target):
    left, right = 0, len(arr)-1
    while left <= right:
        mid = left + (right-left)//2
        if arr[mid] == target:
            return mid
        if arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1

if __name__ == "__main__":
    a = [1,3,5,7,9,11,13,15,17,19]
    t = 7
    print("Array:", a)
    print("Target:", t)
    print("Index:", binary_search(a, t))
