"""
Interpolation Search - recursive implementation (works on uniformly distributed sorted arrays).
Returns index or -1.
"""

def interpolation_search(arr, lo, hi, x):
    if lo <= hi and arr[lo] != arr[hi] and x >= arr[lo] and x <= arr[hi]:
        pos = lo + ((hi - lo) * (x - arr[lo])) // (arr[hi] - arr[lo])
        if pos < 0 or pos >= len(arr):
            return -1
        if arr[pos] == x:
            return pos
        if arr[pos] < x:
            return interpolation_search(arr, pos+1, hi, x)
        if arr[pos] > x:
            return interpolation_search(arr, lo, pos-1, x)
    elif lo <= hi and arr[lo] == arr[hi] and arr[lo] == x:
        return lo
    return -1

if __name__ == "__main__":
    a = [10,20,30,40,50,60,70,80,90]
    x = 50
    print("Array:", a)
    print("Target:", x)
    print("Index:", interpolation_search(a, 0, len(a)-1, x))
