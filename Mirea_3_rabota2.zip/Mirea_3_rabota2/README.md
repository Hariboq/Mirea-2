# Mirea_3_rabota2 — Алгоритмы и Поиски (11 примеров)

В этом каталоге находятся 11 реализаций классических алгоритмов сортировки и поиска на Python:

1. `01_selection_sort.py` — сортировка выбором (Selection Sort)  
2. `02_bubble_sort.py` — сортировка обменом (Bubble Sort)  
3. `03_insertion_sort.py` — сортировка вставками (Insertion Sort)  
4. `04_merge_sort.py` — сортировка слиянием (Merge Sort)  
5. `05_shell_sort.py` — сортировка Шелла (Shell Sort)  
6. `06_quick_sort.py` — быстрая сортировка (Quick Sort)  
7. `07_heap_sort.py` — пирамидальная сортировка (Heap Sort)  
8. `08_linear_search.py` — последовательный поиск (Linear Search)  
9. `09_binary_search.py` — бинарный (двоичный) поиск (Binary Search)  
10. `10_interpolation_search.py` — интерполяционный поиск (Interpolation Search)  
11. `11_fibonacci_search.py` — поиск по Фибоначчи (Fibonacci Search)  

---

## Как запустить

Каждый файл можно запускать отдельно в терминале (Python 3.8+):

```bash
python3 01_selection_sort.py
```

## Как выложить на GitHub (краткая инструкция)

1. Создайте репозиторий на GitHub (например `Mirea_3_rabota2`).  
2. На локальной машине выполните:

```bash
git init
git add .
git commit -m "Add 11 algorithms (sorts & searches)"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```

Если вы не знакомы с командной строкой, можно просто загрузить файлы через веб-интерфейс GitHub (кнопка "Add file" → "Upload files").

## Структура репозитория

- Каждый алгоритм в отдельном `.py` файле с простым примером в `if __name__ == "__main__":`
- Этот README.md — краткое описание и инструкция по загрузке

---

Если нужно — могу:
- оформить всё в ZIP-файл и дать ссылку для скачивания;
- добавить единый тестовый скрипт `run_all_tests.py`;
- перевести README на русский/английский или добавить ссылки на источники.
